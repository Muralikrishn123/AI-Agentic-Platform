﻿from .plugin import GenericDomainPlugin
